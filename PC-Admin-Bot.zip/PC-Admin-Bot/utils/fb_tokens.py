import time
from typing import Dict, Tuple, Optional

# user_id -> token -> (path, ts)
fb_token_map: Dict[int, Dict[str, Tuple[str, float]]] = {}
FB_TOKEN_TTL = 300


def add_token(user_id: int, token: str, path: str) -> None:
    fb_token_map.setdefault(user_id, {})[token] = (path, time.time())


def resolve_token(user_id: int, token: str) -> Optional[str]:
    ent = fb_token_map.get(user_id, {}).get(token)
    if ent:
        return ent[0]
    return None


def cleanup(user_id: int) -> None:
    now = time.time()
    user_map = fb_token_map.get(user_id)
    if not user_map:
        return
    to_delete = [t for t, (p, ts) in user_map.items() if now - ts > FB_TOKEN_TTL]
    for t in to_delete:
        user_map.pop(t, None)
    if not user_map:
        fb_token_map.pop(user_id, None)


def clear_user(user_id: int) -> None:
    fb_token_map.pop(user_id, None)


def get_map_copy():
    # helper for tests/debug
    return {k: dict(v) for k, v in fb_token_map.items()}
